// JavaScript для VPN Telegram Bot Admin Panel

document.addEventListener('DOMContentLoaded', function() {
    // Инициализация навигации
    initNavigation();
    
    // Инициализация графиков
    initCharts();
    
    // Обработчик кнопки входа
    initLoginButton();
});

// Функция инициализации навигации
function initNavigation() {
    const navLinks = document.querySelectorAll('#sidebar .nav-link');
    const contentSections = document.querySelectorAll('.content-section');
    
    // Обработчик для ссылок навигации
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Получаем ID целевой секции из атрибута href
            const targetId = this.getAttribute('href').substring(1);
            
            // Если это выход, показываем страницу входа
            if (targetId === 'logout') {
                hideAllSections();
                document.getElementById('login').classList.add('active-section');
                return;
            }
            
            // Скрываем все секции и показываем целевую
            hideAllSections();
            const targetSection = document.getElementById(targetId);
            if (targetSection) {
                targetSection.classList.add('active-section');
            }
            
            // Обновляем активную ссылку
            navLinks.forEach(link => link.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    // Функция скрытия всех секций контента
    function hideAllSections() {
        contentSections.forEach(section => {
            section.classList.remove('active-section');
        });
    }
}

// Функция инициализации графиков
function initCharts() {
    // График продаж
    const salesCtx = document.getElementById('salesChart');
    if (salesCtx) {
        new Chart(salesCtx, {
            type: 'line',
            data: {
                labels: ['1 Мар', '5 Мар', '10 Мар', '15 Мар', '20 Мар', '25 Мар', '30 Мар', '1 Апр', '4 Апр'],
                datasets: [{
                    label: 'Продажи',
                    data: [3, 5, 7, 12, 8, 10, 15, 18, 12],
                    borderColor: '#0d6efd',
                    tension: 0.3,
                    fill: false
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    // График продуктов
    const productsCtx = document.getElementById('productsChart');
    if (productsCtx) {
        new Chart(productsCtx, {
            type: 'doughnut',
            data: {
                labels: ['Premium 1 мес', 'Pro 3 мес', 'Ultra 6 мес', 'Годовой'],
                datasets: [{
                    data: [42, 28, 18, 12],
                    backgroundColor: [
                        '#0d6efd',
                        '#198754',
                        '#6f42c1',
                        '#fd7e14'
                    ],
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
}

// Функция инициализации кнопки входа
function initLoginButton() {
    const loginButton = document.getElementById('login-button');
    if (loginButton) {
        loginButton.addEventListener('click', function() {
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            
            // Простая проверка на демо-данные
            if (username === 'admin' && password === 'admin') {
                // Скрываем страницу входа и показываем панель управления
                document.getElementById('login').classList.remove('active-section');
                document.getElementById('dashboard').classList.add('active-section');
                
                // Активируем первую ссылку в навигации
                const firstNavLink = document.querySelector('#sidebar .nav-link');
                if (firstNavLink) {
                    document.querySelectorAll('#sidebar .nav-link').forEach(link => {
                        link.classList.remove('active');
                    });
                    firstNavLink.classList.add('active');
                }
            } else {
                alert('Неверное имя пользователя или пароль. Для демо используйте admin/admin');
            }
        });
    }
}